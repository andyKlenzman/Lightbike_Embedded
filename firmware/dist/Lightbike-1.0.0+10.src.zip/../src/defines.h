#pragma once


#define NUM_PIXELS (50)