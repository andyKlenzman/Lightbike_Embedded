#pragma once

/* These are declarations.
 *
 * They tell other files, 'I promise, these functions exist'
 *
 * It is copied in pasted everywhere these functions are used.
 *
 * They are included into CPP files.
 *
 * A declaration can exist in the same file as a defintion without problems.
 * */

/* Dieser shöne erste Tile hießt ein Function Signature */
void simulateAccelerometerData(SensorData accel_data[3]);


void simulateGyroscopeData(SensorData gyro_data[3]);
