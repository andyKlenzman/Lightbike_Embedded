#include "utils/print-functions/SEGGER_RTT.h"
#include "data_types/defines.h"
#include <ctime>

void simulateAccelerometerData(SensorData accel_data[3]) {
    // Seed the random number generator
    srand(time(NULL));

    // Generate random accelerometer data
    for (int i = 0; i < 3; i++) {
        int rand_int = (rand() % 4000) + 1; // Generate random integer between 1 and 4000
        accel_data[i] = rand_int;
        SEGGER_RTT_printf(0,  "%d", rand_int);
        SEGGER_RTT_printf(0,  "dfsafs");



    }
}


// Function to simulate gyroscope data
void simulateGyroscopeData(SensorData gyro_data[][3], int num_points) {
    // Seed the random number generator
    srand(time(NULL));

    // Generate random gyroscope data
    for (int i = 0; i < num_points; i++) {
        for (int j = 0; j < 3; j++) {
            gyro_data[i][j] = (double) (rand() % 1000) / 100.0; // Generating random values between 0.0 and 10.0
        }
    }
}