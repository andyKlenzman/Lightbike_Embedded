#include "data_types/defines.h"
#include "sensorSimulator.h"

///---  ----///

/*********************************************************************
*
*  Updates the public member arrays for Velocity and Orientation instances
*  with the latest reading from the sensors.
*
**********************************************************************
*/

void getAccelerometerData() {
    /* How will I read data from the driver ?*/
    simulateAccelerometerData(accelerometerData);
};

void getGyroscopeData() {
    /* How will I read data from the driver ?*/
    SensorData newData[3] = {5, 10, 15};

    for (int i = 0; i < 3; ++i) {
        gyroscope_data[i] = newData[i];
    }
};




