#pragma once

void getAccelerometerData();

void getGyroscopeData();


