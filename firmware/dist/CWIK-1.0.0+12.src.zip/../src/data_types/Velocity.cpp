#include "Velocity.h"

/* Maybe I will put the filtering into these objects, it might also take in both data types.
 * I might do one object that yields both velocity and data, since I'll need to probably
 * use both data sources to get the most accurate value.
 *
 * */


Velocity::Velocity (SensorData initial_value) {
    set(initial_value);
}


void Velocity::set(SensorData new_value) {
    /* find a way to save changes in changes of degrees to a value that
     * 1) tracks change over time
     * 2) keeps the value positive
     * 3) translate acceleration to velocity
     *
     *
     * */

}

SensorData Velocity::get() const {
    return value;


}