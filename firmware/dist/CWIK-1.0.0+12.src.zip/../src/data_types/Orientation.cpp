#include "Orientation.h"

Orientation::Orientation (SensorData initial_value) {
    set(initial_value);
}


void Orientation::set(SensorData new_value) {
    /* find a way to save changes in changes of degrees to a value that
     * 1) tracks change over time
     * 2) keeps the value within 360 degrees, even when it goes over or under,
     *      to represent the position of the bike in a circle.
     *
     * */

}

SensorData Orientation::get() const {
    return value;


}