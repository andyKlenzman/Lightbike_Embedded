#include "defines.h"


SensorData accelerometerData[3] = {};
SensorData gyroscope_data[3] = {};


/* Representation of the LED strip */
int LEDS[NUM_LEDS][RGB] = {};