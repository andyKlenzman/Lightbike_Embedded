#pragma once
#include "defines.h"


class Velocity {
private:
    SensorData value{}; // Internal representation of the angle

public:
    // Constructor
    explicit Velocity(SensorData initial_value = 0.0);

    // Member function that sets the velocity value from sensor data
    void set(SensorData new_value);

    // Member function that sets the angle value
    [[nodiscard]] SensorData get() const;
};



