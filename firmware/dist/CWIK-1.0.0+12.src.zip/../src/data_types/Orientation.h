#pragma once
#include "defines.h"

class Orientation {

private:
    SensorData value{}; // Internal representation of the angle

public:

    SensorData accelerometerData;
    // Constructor
    //      explicit keyword means you can not do implicit conversions.
    //      Implicit conversions automatically convert types to the parameters type
    //      By throwing an error, we avoid misunderstanding in the code.
    explicit Orientation(SensorData initial_value = 0.0);

    // Member function that sets the orientation value, ensuring it stays within 0-360 range
    void set(SensorData new_value);

    // Member function that sets the angle value
    //      [[nodiscard]] is a compiler directive. It tells the user
    //      if there is a return value that is not meant to be ignored
    [[nodiscard]] SensorData get() const;
};