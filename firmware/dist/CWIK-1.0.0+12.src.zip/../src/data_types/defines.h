#pragma once

///--- Generic Defines for readability ----///
#define NUM_LEDS 50
#define RGB 3


///--- Core Data Types ----///
typedef double SensorData;

extern SensorData accelerometerData[3];
extern SensorData gyroscope_data[3];


/* Representation of the LED strip */
extern int LEDS[NUM_LEDS][RGB];
