#include <sysconfig.h>

/* Okay I am going to make a driver and plug it into coldwave. The answer, I believe, is somewhere in coldwave.
 *
 *
 *
 * */
///  List all the drivers that should get linked in



sysconf_use_driver(iadc_gecko)
sysconf_use_driver(cmu_gecko)
sysconf_use_driver(spi_gecko)
sysconf_use_driver(euart_gecko)
//sysconf_use_driver(ble_gecko)
//sysconf_use_driver(virtual_ble_uart)
sysconf_use_driver(quectel_bg77_gsmmodem)

/// Now declare which driver specific properties
/// (see driver's readme/guide) you intend to use

sysconf_declare_param(quectel_bg77_pwrkey_gpio)
sysconf_declare_param(quectel_bg77_status_gpio)

/// ...and last not least, create devices from specific drivers and set params
/// Note that we reference the drivers by their actual name,
/// while above at linking we referred to their linker names.

sysconf_create_device("silabs-gecko-cmu", sysclk, 0,
sysconf_set_str_param(clock, "dpll"),
sysconf_set_str_param(clocksrc, "hfxo"),
sysconf_set_int_param(clocksrc_freq, 39000000UL),
sysconf_set_int_param(frequency_hz, 80000000UL))


sysconf_create_device("silabs-gecko-spi", spi0, 0x5005C000UL,
sysconf_set_int_param (gpio_mosi, 100),
sysconf_set_int_param (gpio_clk, 101),
sysconf_set_int_param (gpio_cs, 102),
sysconf_set_int_param (gpio_miso, 103),
sysconf_set_int_param (mode, 512),
sysconf_set_int_param (baudrate, 250000))

sysconf_create_device("silabs-gecko-euart", eusart1, 0x500A0000UL,
sysconf_set_int_param (gpio_rx, 201),
sysconf_set_int_param (gpio_tx, 202),
sysconf_set_int_param (gpio_rts, 203),
sysconf_set_int_param (gpio_cts, 204))

sysconf_create_device("quectel-bg77", modem0, 0x0,
sysconf_set_parent_dev(eusart1),
        sysconf_set_int_param (gpio_dtr, 200),
sysconf_set_int_param (gpio_dcd, 206),
sysconf_set_int_param (gpio_ri, 207),
sysconf_set_int_param (quectel_bg77_status_gpio, 205),
sysconf_set_int_param (quectel_bg77_pwrkey_gpio, 300))

//sysconf_create_device("silabs-gecko-ble", ble0, 0x0)
//sysconf_create_device("virtual-ble-uart", uart0, 0x0,
//					  sysconf_set_parent_dev(ble0))

sysconf_create_device("silabs-gecko-iadc", iadc0, 0x0)