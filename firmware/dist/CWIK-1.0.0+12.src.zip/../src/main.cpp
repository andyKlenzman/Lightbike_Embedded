#include "data_types/defines.h"
#include <kernel.h>
#include <gpio.h>
#include "leds/leds.h"
#include "sensors/sensors.h"
#include "utils/utils.h"

int main(void) {
    /* Initialize WS2812b leds*/

    /* Initialize accelerometer */

    /* Initialize gyroscope */

    /* Initialize buttons */


    while (1) {
        uint32_t ts = osKernelGetTickCount();

        /* Get values for accelerometerData and gyroscope_data */
        getAccelerometerData();
        getGyroscopeData();

        /* Transform accelerometerData and gyroscope_data into the RGB values in LEDS */
        updateLEDState(&LEDS, accelerometerData, gyroscope_data);

        /* Achieve 30 FPS by pausing until 33.34ms have passed since the beginning of the loop */
        regulateFPS(ts);

        /* Push LEDS to WS2812b */
        setLEDS();

    }
};

