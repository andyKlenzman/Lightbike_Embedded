#pragma once

void setLEDS();

void updateLEDState(int (*output_leds)[NUM_LEDS][RGB], const SensorData input_accel_data[],
                    const SensorData input_gyro_data[]);