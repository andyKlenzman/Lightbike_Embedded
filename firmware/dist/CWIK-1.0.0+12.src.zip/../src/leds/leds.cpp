#include "data_types/defines.h"

/* Updates the virtual LED array */
void updateLEDState(int (*output_leds)[NUM_LEDS][RGB], const SensorData input_accel_data[],
                    const SensorData input_gyro_data[]) {


}

/* Pushes the updated virtual LED array to the physical leds */
void setLEDS() {

}
